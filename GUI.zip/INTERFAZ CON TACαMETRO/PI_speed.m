%% INTERFAZ  CONTROL PI VELOCIDAD

function varargout = INTERFAZ(varargin)
fclose('all')
global  parar SerialP Popen puerta
parar = true; Popen = false;

    fig(1)=figure('name','Control P+I de Velocidad ','menubar','none','position',[100 100 700 647],'color',[0.94 0.94 0.94]);
    movegui(fig(1),'center'); fig(1).Resize='off';
    
    texto(3)=uicontrol('parent',fig(1),'style','text','string','CONTROL P+I DE VELOCIDAD','position',[60 605 650 30],'BackgroundColor',[0.94 0.94 0.94],'fontsize',22,...
                    'FontName','Courier New','FontWeight','bold');
    
    panel(1) = uipanel('Title','PI tunning','FontSize',14,'BackgroundColor',[0.94 0.94 0.94],'units','characters','Position',...
                        [100 34 34 12],'FontWeight','bold','FontName','Courier New','BorderWidth',3.0);

    
    texto(1)=uicontrol('parent',panel(1),'style','text','string','Kp:      Ki:  ','position',[12 15 35 100],'BackgroundColor',[0.94 0.94 0.94],'fontsize',12,...
                    'FontWeight','bold');
              
    kp=uicontrol('parent',panel(1),'style','edit','String','2.5','position',[50 89 101 26],'fontsize',14,'FontName','Courier New','Enable','off');
    ki=uicontrol('parent',panel(1),'style','edit','String','0.5','position', [50  55  101 26],'fontsize',14,'FontName','Courier New','Enable','off');
   
    tunning_button=uicontrol('parent',panel(1),'style','pushbutton','string','SET','BackgroundColor',[0.96 0.96 0.96],'ForegroundColor',[0 0 0],'position',[55 10 60 26],'callback',@tunning,...
                               'fontsize',11, 'FontWeight','bold','Enable','off');
                            
     panel(2) = uipanel('Title','Speed','FontSize',14,'BackgroundColor',[0.94 0.94 0.94],'units','characters','Position',...
                        [100 22 34 10],'FontWeight','bold','BorderWidth',3.0,'FontName','Courier New');
                    
     texto(2)=uicontrol('parent',panel(2),'style','text','string',' RPM: ','position',[8 12 60 71],'BackgroundColor',[0.94 0.94 0.94],'fontsize',13,...
                    'FontWeight','bold');
 
     rpm=uicontrol('parent',panel(2),'style','edit','position', [76  60  65 26],'fontsize',12,'Enable','off');
   
     sp_button=uicontrol('parent',panel(2),'style','pushbutton','string','SET','BackgroundColor',[0.96 0.96 0.96],'ForegroundColor',[0 0 0],'position',[57 12 60 26],'callback',@setpoint,...
                                'fontsize',11, 'FontWeight','bold','Enable','off');
                            
     panel(3) = uipanel('FontSize',10,'BackgroundColor',[0.94 0.94 0.94],'units','characters','Position',...
                        [41 1 20 4],'FontWeight','bold','BorderWidth',2.0,'FontName','Courier New');                        
                    
                            
      rpm_=uicontrol('parent',panel(3),'style','tex','string',' ','position',[10 11 70 30],'BackgroundColor',[1 1 1],'fontsize',15, 'FontWeight','bold');
    
boton_go=uicontrol('parent',fig(1),'style','pushbutton','string','GO','BackgroundColor',[0.96 0.96 0.96],'ForegroundColor',[0 0 0],'position',[540 240 100 34],'callback',@go,'fontsize',14, 'FontWeight','bold');
boton_stop=uicontrol('parent',fig(1),'style','pushbutton','string','STOP','BackgroundColor',[0.96 0.96 0.96],'ForegroundColor',[0 0 0],'position',[540 140 100 34],'callback',@stop,'fontsize',14,'FontWeight','bold','Enable','off');
boton_off_motor=uicontrol('parent',fig(1),'style','pushbutton','string','Off Motor','BackgroundColor',[0.96 0.96 0.96],'ForegroundColor',[0 0 0],'position',[540 190 100 34],'callback',@off_motor,'fontsize',14,'FontWeight','bold','Enable','off');
boton_close=uicontrol('parent',fig(1),'style','pushbutton','string','CLOSE','BackgroundColor',[1 0.3 0.22],'ForegroundColor',[0 0 0],'position',[540 90 100 34],'callback',@closeapp,'fontsize',14,'FontWeight','bold','Enable','on');

axe(1)=axes('parent',fig(1),'units','pixels','position',[50 327 382 267],'xlim',[-150 150],'ylim',[0 80],'xgrid','on','ygrid','on','Box','On','Linewidth',2,'FontName','Courier New',...
              'fontsize',9, 'FontWeight','bold');

axe(2)=axes('parent',fig(1),'units','pixels','position',[145 30 220 220]);


set(get(axe(1),'XLabel'),'String','Tiempo (ms)');
set(get(axe(1),'YLabel'),'String','Velocidad (rpm)');


%  lin(1)=line('parent',axe(1),'xdata',[],'ydata',[],'Color','g','LineWidth',2.5);
%  lin(2)=line('parent',axe(2),'xdata',[],'ydata',[],'Color','m','Linewidth',2.5);
   ports = seriallist;
   puerta =ports(1);
popup = uicontrol('parent',fig(1),'Style', 'popup','String', ports,'Position', [540 15 100 50],'fontsize',12,'FontName','Courier New','Callback', @puertas); 

%% gauge RPM
    axeshandle=axe(2);
    minvalue=0;
    maxvalue=80;
    steps=100;
    substeps=5;
    textsteps=10;
    unit='pixels';
    %value increment with one step
    stepvalue=(maxvalue-minvalue)/steps;
    stepangle=1.5*pi/steps;

    %set gca
    set(gcf,'CurrentAxes',axeshandle);

    %real world ratio
    set(axeshandle,'DataAspectRatio',[1 1 1]);

    %no axis shown
    axis off;

    %set boundaries
    axis([-1.1 1.1 -1.1 1.1]);

    %white background
    rectangle('Position',[-1.1,-1.1,2.2,2.2],'Curvature',[1,1],'FaceColor','w');

    %create tacho object
    
    objTacho.linehandle=line('linewidth',2,'xdata',[0 cos(1.25*pi)],'ydata',[0 sin(1.25*pi)]);
    objTacho.axeshandle=axeshandle;
    objTacho.minvalue=minvalue;
    objTacho.maxvalue=maxvalue;
    objTacho.stepvalue=stepvalue;
    objTacho.stepangle=stepangle;
    objTacho.steps=steps;
    objTacho.unit=unit;

    %create scala
    for i=0:steps
        %the curent angle
        %phi=1.5*pi/steps*(steps-i)-0.25*pi;
        phi=-1.5*pi/steps*i+1.25*pi;

        x=cos(phi);
        y=sin(phi);

        %long or short scala lines?
        if(mod(i,substeps))
            line([0.95*x x],[0.95*y y]);
        else
            line([0.9*x x],[0.9*y y]);
        end

        %print values
        if(~mod(i,textsteps))
            text(x*0.7,y*0.7,num2str(i*stepvalue+minvalue),'HorizontalAlignment','center');
        end
    end

    text(0,-0.3,'RPM','HorizontalAlignment','center');

    set(axeshandle,'UserData',objTacho);

    %default value
    updateTacho(axeshandle,0);
    
    %% Funcion Puerto
    function varargout=puertas(hObject,evendata)
        puerta=popup;
    end

    %% Funcion STOP
    function varargout=stop(hObject,evendata)
        
       
         fwrite(SerialP,"G0.0F",'uchar');
         updateTacho(axeshandle,0);set(rpm_,'string',' ');set(rpm,'string',' ');
         cla(axe(1));
       
        parar=true;   
        pause(0.01);
        set(kp,'Enable','off'); set(ki,'Enable','off'); 
        set(rpm,'Enable','off');
        set(sp_button,'Enable','off');  set(tunning_button,'Enable','off');
        set(boton_go,'Enable','on');set(boton_stop,'Enable','off');set(boton_stop,'BackgroundColor',[0.98 0.95 0.1]);
        set(boton_close,'Enable','on'); set(boton_off_motor,'Enable','off');  
        set(boton_go,'BackgroundColor',[0.96 0.96 0.96]);
        
    end
    %% Funcion OFF MOTOR
    function varargout=off_motor(hObject,evendata)

         fwrite(SerialP,"G0.0F",'uchar');
        pause(0.01);
        set(boton_off_motor,'Enable','off'); set(rpm,'string','0');
        
    end
%% Funcion GO
    function varargout=go(hObject,evendata)
        
                delete(instrfind({'Port'},{puerta}))
                SerialP=serial(puerta);
                set(SerialP,'Baudrate',115200); % se configura la velocidad a 115200 Baudios
                set(SerialP,'StopBits',1); % se configura bit de parada a uno
                set(SerialP,'DataBits',8); % se configura que el dato es de 8 bits, debe estar entre 5 y 8
                set(SerialP,'Parity','none'); % se configura sin paridad
                
                fopen(SerialP);Popen=true;
                parar=false;

            parar=false; Popen = true;
            set(boton_go,'BackgroundColor',[0.1 0.97 0.16]); set(boton_go,'Enable','off');
            set(boton_stop,'Enable','on');set(boton_stop,'BackgroundColor',[0.96 0.96 0.96]);
            set(boton_close,'Enable','off');
            set(kp,'Enable','on'); set(ki,'Enable','on'); set(rpm,'Enable','on'); 
             set(sp_button,'Enable','on');  set(tunning_button,'Enable','on');   
            GRAFICADOR();
            
    end
%% Funcion CLOSE
    function varargout=closeapp(hObject,evendata)
             
        if (Popen)
                fclose(SerialP);
                delete(SerialP);
                clear SerialP;
                Popen = false;
        end
                delete(fig(1));
                
    end

%% Funcion PI TUNNING
    function varargout=tunning(hObject,evendata)
        
             ps=get(kp,'String');
            is=get(ki,'String');
            
            pp=str2num(ps);
            ii=str2num(is); 
            
            sp=num2str(pp,'%2.3f');
            si=num2str(ii,'%2.3f');

         if ( sp~="" && si~="" )
             s1='P';s11='F';kpro = strcat(s1,sp,s11);
             fwrite(SerialP,kpro,'uchar'); %Enviar Kp
             s2='I';s22='F';kint = strcat(s2,si,s22);
             fwrite(SerialP,kint,'uchar'); %Enviar Ki

         end
    end

%% Funcion SETPOINT
    function varargout=setpoint(hObject,evendata)

             ss1='G';
             rpm_s=get(rpm, 'String');
             rpm1=str2num(rpm_s);
             rpm_final=num2str(rpm1,'%2.1f');
             ss2 = 'F';
        
        if ( rpm_final~="")
            ss= strcat(ss1,rpm_final,ss2);
             fwrite(SerialP,ss,'uchar');
        end
 
        set(boton_off_motor,'Enable','on');
    end


%% GRAFICADOR
    function GRAFICADOR()

         tiempo1=[0];
        salida1=[0];
          
         lin(1)=line('parent',axe(1),'xdata',[],'ydata',[],'Color','g','LineWidth',2.5);

        limx1=[-150 150];limy1=[0 80];
        set(axe(1),'xlim',limx1,'ylim',limy1);
        
        
    while(~parar) %mientras para sea false
        
        q=(fscanf(SerialP,'%s',1));
        v= (fscanf(SerialP,'%f'));

        tiempo1=[tiempo1 tiempo1(end)+1];
        salida1=[salida1 v];
       
        set(lin(1),'xdata',tiempo1,'ydata',salida1);
        set(rpm_,'string',v); %escribe valor actual de rpms
        updateTacho(axeshandle,v);
        
       
    pause(0.01);
         
              limx1=[limx1(1)+1  limx1(2)+1];
               set(axe(1),'xlim',limx1) ;
            
%              if (tiempo1(end)>=limx1) 
%              limx1=[limx1(1)  limx1(2)+200];
%              set(axe(1),'xlim',limx1) ;
%              end
             
             
             if (salida1(end)>=limy1) % En caso de que la velocidad supere el l�mite de 76 rpms..
             limy1=[0 limy1(2)+0.1];
             set(axe(1),'ylim',limy1); 
             end
             
    end
    end

end